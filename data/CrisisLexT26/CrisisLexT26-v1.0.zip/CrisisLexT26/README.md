Contents of this directory
==========================

This directory contains tweets posted during a series of crisis events. See the README.md files inside each directory for details.

Reference
---------
[Olteanu et al. 2015] Alexandra Olteanu, Sarah Vieweg, Carlos Castillo. 2015. What to Expect When the Unexpected Happens: Social Media Communications Across Crises. In Proceedings of the ACM 2015 Conference on Computer Supported Cooperative Work and Social Computing (CSCW '15). ACM, Vancouver, BC, Canada.

Questions/inquiries
-------------------
For inquiries please contact [Alexandra Olteanu](mailto:alexandra.olteanu@epfl.ch), or Sarah Vieweg, or Carlos Castillo.
 
Version history
---------------

 * 2014-10-26: v1.0, initial release.

